package edu.cofc.csci230;
 //import java.util.LinkedList;
 
/**
 * Singly LinkedList Data Structure
 * 
 * @author CSCI 230: Data Structures and Algorithms Fall 2017
 *
 * @param <AnyType>
 */
public class SinglyLinkedList<AnyType extends Comparable<AnyType>> implements List<AnyType> {
     
    // instance variables
    private Node<AnyType> headNode = null;
    private int size = 0;
 
    /**
     * Appends the specified element to the end of this list.
     * 
     * @param t
     */
    public void add( AnyType t) throws IndexOutOfBoundsException {
         
        addNode( new Node<AnyType>(t) );
         
    } // end add() method
    
    /**
     * implementation for public add(AnyType t) method
     * 
     * @param t
     */
    private void addNode(Node<AnyType> t) throws IndexOutOfBoundsException {
        
    	//if the list is empty set the headnode to equal t
        if ( isEmpty() ){ 
        	headNode = t;
        }//if the head list is not empty get the last node and set it to t
        else getNode( size-1 ).setNextNode( t );
        //dont forget to add 1 to the size
        size++;
         
    } // end addNote() method
 
 
    /**
     * Inserts the specified element at the specified position in this list.
     * 
     * @param index
     * @param t
     * @throws IndexOutOfBoundsException
     */
    public void add(int index, AnyType t) throws IndexOutOfBoundsException {
         
    	addNode( index, new Node<AnyType>(t) );
         
    } // end add() method
    
    /*
     * 
     * Implementation for public add(int index, AnyType t) method
     *
     * @param index
     * @param t
     * @throws IndexOutOfBoundsException
     */
    private void addNode(int index, Node<AnyType> t) throws IndexOutOfBoundsException {
    	//index out of bounds exception
    	if(index > size || index < 0){
    		throw new IndexOutOfBoundsException();
    	}
     
    	if(index == 0){ //front of the list
    		t.setNextNode(headNode);
    		headNode = t;
    		//add to size since you are adding to the list
    		size++;
    	}else if(index == size){ //end of the list
    		getNode(size-1).setNextNode(t);
    		//add to size since you are adding to the list
    		size++;
    	}else{ //middle of the list
    		getNode(index-1).setNextNode(t);
    		//add to size since you are adding to the list
    		size++;
    	}
        
    } // end addNode() method

    public void set(int index, AnyType t) throws IndexOutOfBoundsException {
         
        setNode( index, new Node<AnyType>(t) );
         
    } // end set() method
    
    /**
     * 
     * Implementation for public set( int index, AnyType t ) method
     *
     * @param index
     * @param t
     * @throws IndexOutOfBoundsException
     */
    private void setNode( int index, Node<AnyType> t ) throws IndexOutOfBoundsException {
    	//index out of bounds exception
    	if(index > (size -1) || index < 0){
    		throw new IndexOutOfBoundsException();
    	}
     
    	//if the index is the the end set the node before it to t 
    	if(index == size -1){
    		getNode(size-2).setNextNode(t);	
    	}else if(index==0){
        	t.setNextNode(getNode(1));
        	getNode(0).setNextNode(null);
        	t= headNode;
        }else{
        	t.setNextNode(getNode(index+1));
        	getNode(index-1).setNextNode(t);
        }
    } // end setNode() method

    public AnyType remove( int index ) throws IndexOutOfBoundsException {
    	
    	return removeNode(index).getData();
    	
    } // end remove() method
    
    private Node<AnyType> removeNode( int index ) throws IndexOutOfBoundsException {
         
    	if(index > (size - 1) || index < 0){
    		throw new IndexOutOfBoundsException();
    	}
         
    	Node<AnyType> theNode = getNode(index);
    	
    	if(index==0){ //beg of list
    		setNode(1, headNode);
    		getNode(0).setNextNode(null);
    		size--;
    	}else if(index == size -1){ //end & point to null of list
    		getNode(size -2).setNextNode(null);;
        	size--;
        }else{
        	getNode(index-1).setNextNode(getNode(index+1));
        	size--;
        }
        return theNode;
    } // end removeNode() method
 
    public AnyType get( int index ) throws IndexOutOfBoundsException {
    	
    	return getNode( index ).getData();
    	
    	
    } // end get() method
    
    private Node<AnyType> getNode(int index) throws IndexOutOfBoundsException {
         //INDEX OUT OF BOUNDS
    	if(index > (size -1) || index < 0){
    		throw new IndexOutOfBoundsException();
    	}
    	//variable anything
    	Node<AnyType> anything = headNode;
    	
    	//go through the list  
    	for(int i=0; i < index; i++){
    		anything = anything.getNextNode();
    	}
    	return anything;
    } // end get() method

    public int size() {
         
        return size;
         
    } // end size() method
 
    public Boolean isEmpty() {
         
        return ( size == 0 ) ? true : false;
         
    } // end isEmpty() method
     
    public void clear() {
    	//set head node to null and make the size 0
    	headNode = null;
    	size = 0;
    	
    } // end clear method
     
    public static void main( String[] args ) {
         
         SinglyLinkedList<Integer> slist= new SinglyLinkedList<Integer>();
         //test ass
         for(int i =0; i< 3; i++){
        	slist.add(i);
        	//System.out.println(slist.toString());
         }
         //test remove
         for(int i =0; i< slist.size; i++){
        	slist.remove(slist.size-1);
        	System.out.println(i);
         }
        //testadd
        slist.add(33);
        //test set
        //slist.set(2, 9);
        slist.set(1, 22);
        System.out.println(slist.toString());

        //slist.set(4, 21);
        //slist.set(8, 2);
        
        //test get
        for(int i =0; i< slist.size; i++){
        	System.out.println(slist.get(i));
        }
        
        //slist.remove(i);
        //slist.remove(new Integer(i));
        System.out.println(slist.toString());
        
        //test clear
         slist.clear();
         
         System.out.println(slist.toString());
         
    } // end main() method
    
    public String toString() {
		Node<AnyType> temp = headNode; 
		String rtnString = "";
		
		for (int i = 0; i<this.size; i++) {
			rtnString += temp.getData().toString() + " -> ";
			temp = temp.getNextNode();
			
		}
		rtnString += "null";
		
		return rtnString; 
		
	} 
 /**End toString Method**/
  
} // end SinglyLinkedList class definition