package edu.cofc.csci230;


public class SinglyLinkedList_Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		int points = 0;
		ArrayList<Integer> testList = new ArrayList<Integer>();
		ArrayList<Integer> list = new ArrayList<Integer>();
		boolean passed;

		System.out.println("----------------------------------");
		System.out.println("Test Case_1:");

		try {
			list.get(0);
			System.out.println("[Failed]");
		} catch (IndexOutOfBoundsException e){
			System.out.println("[Passed]");
			points += 10;
		}catch(Exception e){
			passed = false; 
			System.out.println("[Failed]");
			
		}

		System.out.println("----------------------------------");
		System.out.println("Test Case_2:");

		passed = true;

		try {

			for(int i = 0; i < 25; i++){
				//System.out.println(i);
				testList.add(i, i);
				list.add(new Integer(i));
			}

		} catch( IndexOutOfBoundsException error ) {
			System.out.println( "Got IndexOutOfBoundsException when adding elements to list." );
			passed = false;
		} catch (Exception e){
			System.out.println(e);
			System.out.println("[Failed]");
			passed = false;

		}

		if ( passed ) {

			try{
				for (int i = 0; i < 25; i++){
					if(testList.get(i).intValue() != list.get(i).intValue() )
						passed = false;
				}
			} catch (IndexOutOfBoundsException e){
				System.out.println( "Got IndexOutOfBoundsException when getting elements from list." );
				passed = false;
			} catch (Exception e){
				System.out.println(e);
				System.out.println("[Failed]");
				passed = false;
			
			}

		}

		if(passed){
			System.out.println("[Passed]");
			points += 10;
		} 
		else{
			System.out.println("[Failed]");
		}

		System.out.println("----------------------------------");
		System.out.println("Test Case_3:");

		try {

			list.clear();

			if(list.isEmpty()){
				System.out.println("[Passed]");
				points += 10;
			}
			else{
				System.out.println("[Failed]");
			}

		} catch( IndexOutOfBoundsException error ) {
			System.out.println( "Got IndexOutOfBoundsException when clearing the list." );
			System.out.println("[Failed]");
		} catch(Exception e){
			System.out.println(e); 
			System.out.println("[Failed]");
		}

		testList.clear();

	
		System.out.println("----------------------------------");
		System.out.println("Test Case_4:");

		passed = true;

		try{
			for(int i = 0; i < 5; i++){
				testList.add(i, i);
				list.add(i, new Integer(i));
			}
		} catch (IndexOutOfBoundsException e){
			System.out.println( "Got IndexOutOfBoundsException when adding elements to the list." );
			passed = false;
		}catch (Exception e){
			System.out.println(e);
			passed = false;
		}

		try{
			for (int i = 0; i < 5; i++){
				if(testList.get(i).intValue() != list.get(i).intValue() )
					passed = false;
			}
		} catch (IndexOutOfBoundsException e){
			passed = false;
		}catch (Exception e){
			passed = false;
		}

		try{
			testList.add(3, 6);
			list.add(3, new Integer(6));
		} catch (IndexOutOfBoundsException e){
			System.out.println( "Got IndexOutOfBoundsException when adding element @ index to list." );
			passed = false;
		}catch (Exception e){
			System.out.println(e);
			passed = false;
		}

		try{
			if(testList.get(0).intValue() != list.get(0).intValue() ||
			   testList.get(3).intValue() != list.get(3).intValue() ||
			   testList.get(5).intValue() != list.get(5).intValue() ) {
				passed = false;
			}
		} catch (IndexOutOfBoundsException e){
			System.out.println( "Got IndexOutOfBoundsException when getting elements from list." );
			passed = false;
		}catch (Exception e){
			System.out.println(e);
			passed = false;
		}

		if(passed) {
			System.out.println("[Passed]");
			points += 10;
		} 
		else{
			System.out.println("[Failed]");
		}

		System.out.println("----------------------------------");
		System.out.println("Test Case_5:");
		
		passed = true;

		try{
			
			testList.clear();
			list.clear();
			
			testList.add( 10 );
			testList.add( 5 );
			testList.add( 15);
			testList.add( 7 );
			
			list.add( 10 );
			list.add( 5 );
			list.add( 15);
			list.add( 7 );
			
			testList.set(1, 10);
			list.set(1, new Integer(10));
		} catch (IndexOutOfBoundsException e){
			System.out.println( "Got IndexOutOfBoundsException when setting elements @ index in list." );
			passed = false;
		}catch (Exception e){
			System.out.println(e);
			passed = false;
		}

		try{
			if ( ( list.get(1).intValue() != testList.get(1).intValue() ) || 
				( list.get(2).intValue() != testList.get(2).intValue() ) ) {
				passed = false;
			}
		} catch (IndexOutOfBoundsException e){
			passed = false;
		}catch (Exception e){
			passed = false;
		}

		if(passed){
			System.out.println("[Passed]");
			points += 10;
		} else{
			System.out.println("[Failed]");
		}

		System.out.println("----------------------------------");
		System.out.println("Test Case_6:");

		passed = true;

		try{
			
			testList.clear();
			list.clear();
			
			testList.add( 10 );
			testList.add( 5 );
			testList.add( 15);
			testList.add( 7 );
			
			list.add( 10 );
			list.add( 5 );
			list.add( 15);
			list.add( 7 );
			
			testList.remove(3);
			list.remove(3);
		} catch (IndexOutOfBoundsException e){
			passed = false;
		}catch (Exception e){
			System.out.println(e);
			passed = false;
		}

		try{
			list.get(5);
			System.out.println("[Failed]");
		} catch (IndexOutOfBoundsException e){
			if(passed){
				System.out.println("[Passed]");
				points += 10;
			} else{
				System.out.println("[Failed]");
			}
		}catch (Exception e){
			passed = false;
			System.out.println("[Failed]");
		}

		System.out.println("----------------------------------");
		System.out.println("Test Case_7:");

		if (list.size() == 3){
			System.out.println("[Passed]");
			points += 10;
		} 
		else{
			System.out.println("[Failed]");
		}

		System.out.println("----------------------------------");
		System.out.println("Test Case_8:");

		try {

			testList.clear();
			list.clear();

			if(list.size() != 0){
				System.out.println("[Failed]");
			} else{
				System.out.println("[Passed]");
				points += 10;
			}

		} catch( IndexOutOfBoundsException error ) {
			System.out.println("[Failed]");
		} catch (Exception e){
			System.out.println(e);
			System.out.println("[Failed]");

		}

		System.out.println("----------------------------------");
		System.out.println("----------------------------------");
		System.out.println("---------------------------------------------------------------");
		System.out.println("                            Points Possible    Points Received");
		System.out.println("SinglyLinkedList Compiles         10                 10  ");
		System.out.println("SinglyLinkedList Runs              5                  5  ");
		System.out.println("Thorough test cases                5                    ");
		System.out.println("Instructor Test Cases             80                 " + points);
		System.out.println("    (8 @ 10pts each)");
		System.out.println("                                              Total points: " + (points+15));
		System.out.println("---------------------------------------------------------------");
	}

}