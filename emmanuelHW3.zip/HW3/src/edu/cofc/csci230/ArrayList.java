package edu.cofc.csci230;

import List;

/**
 * ArrayList Data Structure
 * 
 * @author CSCI 230: Data Structures and Algorithms Fall 2017
 *
 * @param <AnyType>
 */
public class ArrayList<AnyType extends Comparable<AnyType>> implements List<AnyType> {

	// instance variables
	private AnyType[] array;
	private int size = 0;
	private final static int INITIAL_CAPACITY = 10;
	private int capacity = INITIAL_CAPACITY;

	public ArrayList() {
		
		//CREATE A NEW ARRAY NAMED ARRAY
		array = (AnyType[]) new Comparable[ capacity ];

	} // end constructor

	public void add( AnyType t) {

		if ( size >= capacity ){
			grow();
		}

		array[size]=t;
		size++;

	} // end add() method

	public void add(int index, AnyType t) throws IndexOutOfBoundsException {
		
		//THROW INDEX OUT OF BOUNDS
		if(index > size || index < 0){
			throw new IndexOutOfBoundsException();
		}

		//IF THE INDEX IS EQUAL TO SIZE -1
		if(index == size - 1){
			add(t);
		}else {
			if ( size >= capacity-1 ){
				grow();
			}
			//COPY ARRAY INTO NEW ARRAY
			AnyType temp = array[index];
			for(int i = index; i <= size + 1; i++){
				temp = array[i];
				array[i] = t;
				t = temp;
			}
			size++;				
		}
	} // end add() method

	public void set(int index, AnyType t) throws IndexOutOfBoundsException {

		//THROW INDEX OUT OF BOUNDS
		if(index > (size -1) || index < 0){
			throw new IndexOutOfBoundsException();
		}

		//loop through the entire array
		for(int i=0; i< array.length; i++){
			array[i] = t;
		}

	} // end set() method

	public AnyType remove( int index ) throws IndexOutOfBoundsException {

		//THROW INDEX OUT OF BOUNDS
		if(index > (size -1) || index < 0){
			throw new IndexOutOfBoundsException();
		}

		//IF THE CAPACITY IS GREATER THAN THE SIZE SHRINK THE LENGTH
		if ( size < capacity ){
			shrink();
		}

		AnyType temp = array[index];
		AnyType retVal = temp;

		for(int i = index; i < size - 1; i++){
			set(i, array[i + 1]);
		}
		size--;
		return retVal;

	} // end remove() method

	public AnyType get(int index) throws IndexOutOfBoundsException {

		//THROW INDEX OUT OF BOUNDS
		if(index > (size -1) || index < 0){
			throw new IndexOutOfBoundsException();
		}

		AnyType shefVal = array[index];

		return shefVal;

	} // end get() method

	public int size() {

		return size;

	} // end size() method

	public Boolean isEmpty() {

		return ( size == 0 );

	} // end isEmpty() method

	public void clear() {

		//create an array
		array = (AnyType[]) new Comparable[ capacity ];
		
		size = 0;
		
		capacity = INITIAL_CAPACITY;

	} // end clear method

	private void grow() {

		//double the entire capacity if the array is full

		//create new array
		AnyType[] anythingArray = (AnyType[]) new Comparable[capacity * 2];

		//copy old array into new array
		for(int i=0; i < size; i++){
			anythingArray[i] = array[i];
		}

		//maintain array and capacity
		capacity = capacity * 2;
		this.array = anythingArray;

	} // end grow() method

	private void shrink() {

		// when you get < 1/2 the elements
		//then shrink the capacity by 1/2

		AnyType[] anythingArray = (AnyType[]) new Comparable[ capacity/2];

		//copy old array into new array
		for(int i=0; i < size; i++){
			anythingArray[i] = array[i];
		}

		//maintain array and capacity
		capacity = capacity/2;
		this.array = anythingArray;

	} // end shrink() method

	/**
	 * For debugging purposes :)
	 * 
	 * Note: this only works for integer values 
	 * hence, the %d format specifier in the 
	 * string format method. If you want a 
	 * different specifier, like string %s, 
	 * you can change.
	 * 
	 */
	public String toString() {

		StringBuffer buffer = new StringBuffer();

		buffer.append( String.format( "Size=%d, A = [ ", size ) );

		if ( !isEmpty() ) {

			for ( int i=0; i<size-1; i++ ) {
				buffer.append( String.format( "%d, ", array[i] ) );    
			}

			buffer.append( String.format( "%d ]", array[size-1] ) );

		} else {

			buffer.append( " ] " );
		}

		return buffer.toString();

	} // end toString()

	public static void main( String[] args ) {

		ArrayList<Integer> shefArray = new ArrayList<Integer>();

		//test add
		//for(int i = 0; i < 10;i++){
			//shefArray.add(i);
			//System.out.print(shefArray.get(i));
		//}

		//ArrayList<Integer> slist = new ArrayList<>();
		
		//test
//		System.out.println();
//		for(int i = 0; i < 3; i++){
//			slist.add(i);
//			System.out.println(slist.toString());
//		}
//		//test remove
//		for(int i =0; i< slist.size; i++){
//			slist.remove(slist.size-1);
//			System.out.println(i);
//		}
		
		//test set
		//slist.set(2, 4);
		//slist.set(1, 22);
		//System.out.println(slist.toString());
		
		//test grow
		//slist.grow();
		//System.out.println(slist.toString());
		//test add
		/*slist.add(33);
		
		//test shrink
		slist.shrink();

		slist.set(4, 21);
		slist.set(8, 2);

		//test get
		for(int i =0; i< slist.size; i++){
			System.out.println(slist.get(i));
		}

		//slist.remove(i);
		//slist.remove(new Integer(i));
		System.out.println(slist.toString());

		//test clear
		slist.clear();*/

		//System.out.println(slist.toString());

	} // end main() method

} // end ArrayList class definition

