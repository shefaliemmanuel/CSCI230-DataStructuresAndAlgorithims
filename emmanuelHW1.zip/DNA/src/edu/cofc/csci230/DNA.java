package edu.cofc.csci230;
import java.util.Scanner;

public class DNA {
	public static void main(String[] args) {
		//scan text in
		Scanner shefScan = new Scanner(System.in);
		//set boolean to true
		boolean checkThis= true;
		int counter=0;
		//create upper and lower character arrays
		char[] UpperArray;
		char[] LowerArray;
		
		System.out.println("Welcome to the DNA Match Up Game!!");
		System.out.println();
		System.out.println("Enter a Upper DNA Strand: ");
		//scan users text
		String upperStrand = shefScan.nextLine();
		//scan users text
		System.out.println("Enter a Lower DNA Strand: ");
		String lowerStrand = shefScan.nextLine();
		
		//makes strands upper case so the program only looks for one type of letter
		upperStrand= upperStrand.toUpperCase();
		lowerStrand= lowerStrand.toUpperCase();
		
		//find the length of the strands for iteration purposes
		int upperLength= upperStrand.length();
		int lowerLength= lowerStrand.length();
		
		//checks to see if strands are empty
		if(upperStrand.length() > 0 && lowerStrand.length() > 0){
			//checks to see if strands are equal in length
			if(upperStrand.length() == lowerStrand.length()){
				//checks to see if strands have special letters
				for(int i=0; i<upperLength; i++)
				{
					//checks to see if the upper strand has A, C, G, or T 
					if(upperStrand.charAt(i) == 'A'|upperStrand.charAt(i) == 'C' |upperStrand.charAt(i) =='G' |upperStrand.charAt(i) =='T'){
						//checks to see if the lower strand has A, C, G, or T 
						if(lowerStrand.charAt(i) =='A' |lowerStrand.charAt(i) =='C' |lowerStrand.charAt(i) =='G' |lowerStrand.charAt(i) =='T'){
						}
						//Error message that notifies the user they have entered an invalid character displayed in the console
						else{
							System.out.println("The entered upper or lower stands must only contain combinations of A, G, C, or T … Exiting program”.");
							checkThis = false;
							break;
							}
					//Error message that notifies the user they have entered an invalid character displayed in the console
					}else{
						System.out.println("The entered upper or lower stands must only contain combinations of A, G, C, or T … Exiting program”.");
						checkThis = false;
						break;
					}}}
			//Error message that notifies the user they have NOT entered the same amount of variables
			else{
				System.out.println("The entered upper and lower strands do not have the same number of chemical bases … Exiting program");
				checkThis = false;
			}}
		else{
			System.out.println("The entered upper strand or lower strand is not defined … Exiting program");
			checkThis = false;
			}
	// for correcting the strand
	if(checkThis){
		//setting variables
		counter = upperStrand.length();
		UpperArray = new char[counter];
		LowerArray = new char[counter];
		boolean finall= true;
		//while loop to iterate through each of the strands
		while(counter > 0){
			UpperArray[counter -1] = upperStrand.charAt(counter-1);
			LowerArray[counter-1] = lowerStrand.charAt(counter-1);
			//counter subtracts one and then restarts the process
			counter--;
		}counter = upperStrand.length();
		//while loop to change each character that is incorrect to the corresponding lowercase letter
		while(counter > 0){
			if(UpperArray[counter-1] =='A'){
				if(LowerArray[counter-1] == 'T'){
					counter--;
				}else{
					finall= false;
					LowerArray[counter-1]= 't';
					counter--;
				}
			}else if(UpperArray[counter-1] =='C'){
				if(LowerArray[counter-1] == 'G'){
					counter--;
				}else{
					finall= false;
					LowerArray[counter-1]= 'g';
					counter--;
				}
			}else if(UpperArray[counter-1] =='G'){
				if(LowerArray[counter-1] == 'C'){
					counter--;
				}else{
					finall= false;
					LowerArray[counter-1]= 'c';
					counter--;
				}
			}else if(UpperArray[counter-1] =='T'){
				if(LowerArray[counter-1] == 'A'){
					counter--;
				}else{
					finall= false;
					LowerArray[counter-1]= 'a';
					counter--;
				}
			}
		}if(finall){
			System.out.println("correct");
		//the final error correction step
		}else{
			String newUpper = new String(UpperArray);
			String newLower = new String(LowerArray);
			System.out.print("The entered double-strand DNA pattern had base-pair errors that have been corrected: " + newUpper + " " + newLower);
		}
	}					
	}
}