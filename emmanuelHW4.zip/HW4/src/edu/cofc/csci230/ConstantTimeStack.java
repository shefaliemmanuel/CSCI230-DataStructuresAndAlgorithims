package edu.cofc.csci230;

import java.util.EmptyStackException;

/**
 * A LIFO stack that has constant time complexity O(1) for
 * all three stack interface methods (i.e., push, pop, and 
 * peek).
 * 
 * This data structure was discussed in class along with the 
 * operations, please review your notes.
 * 
 * @author CSCI 230: Data Structures and Algorithms Fall 2017
 *
 * @param <AnyType>
 */
public class ConstantTimeStack<AnyType extends Comparable<AnyType>> implements Stack<AnyType> {
	
	/**
	 * private instance variables
	 */
	private SinglyLinkedList<AnyType> list = new SinglyLinkedList<AnyType>();

	/**
	 * Pushes an item onto the top of this stack in constant 
	 * time O(1)
	 * 
	 * @param t the item to be pushed onto this stack.
	 */
	public void push(AnyType t) {
		
		list.add(0, t);
		
	} // end push() method

	/**
	 * Removes the object at the top of this stack and return the 
	 * item in constant time O(1)
	 * .
	 * @return The item at the top of this stack
	 * @throws EmptyStackException - if this stack is empty.
	 */
	public AnyType pop() throws EmptyStackException {
		
		return list.remove(0);
		
		
	} // end pop() method

	/**
	 * Looks at the item at the top of this stack without removing it 
	 * from the stack in constant time O(1)
	 * 
	 * @return the item at the top of this stack
	 * @throws EmptyStackException  - if this stack is empty.
	 */
	public AnyType peek() throws EmptyStackException {
		
		if(list.size() == 0){
			throw new EmptyStackException();
		}else{
			return list.get(0);
		}
			
	} // end peek() method
	
	/**
	 * 
	 * @param args
	 */
	public static void main( String[] args ) {
		
		ConstantTimeStack<Integer> myStack = new ConstantTimeStack<Integer>();

		for(int i = 0; i < 10; i++){
		myStack.push(i);
		}

		//push test cases
		myStack.push(-1);
		myStack.push(40);
		myStack.push(0);
		
		//pop test cases
		myStack.pop();
		System.out.println(myStack.pop()); 
		//-1

		for(int j = 0; j < 10; j++){
			myStack.pop();
		}

		//Peek test case
		System.out.println(myStack.peek());

	} // end main method

} // end ConstantTimeStack class definition
